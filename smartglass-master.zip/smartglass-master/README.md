# smartglass
place bitmap and arduino file in same folder on your desktop.
